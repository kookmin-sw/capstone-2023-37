package com.recommend.application.utils;

public class Constants {
    public static final String PHONE = "phone";
    public static final String PASSWORD = "password";
    public static final String TYPE = "type";
}
