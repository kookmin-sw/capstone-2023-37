package com.recommend.application.fragment;


import com.recommend.application.R;
import com.recommend.application.base.BaseFragment;


public class HomeFragment extends BaseFragment {



/*
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false);
    }
*/



    @Override
    protected int getLayoutId() {
        return R.layout.fragment_home;
    }

    @Override
    protected void initEventAndData() {

    }


}
